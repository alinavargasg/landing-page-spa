export const environment = {
  production: false,
  // URL del backend (con el que se conectará para guardar los contactos)
  apiUrl: 'http://localhost:3000/api/createContact'  
};