export const environment = {
  production: true,
  apiUrl: 'https://tudominio.com/api'  // URL de tu API en producción
};